# goldenmask

Protect your python source code with one command.