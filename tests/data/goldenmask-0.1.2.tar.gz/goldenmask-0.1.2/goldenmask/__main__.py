import sys

if '__name__' == '__main__':
    from goldenmask.cli import goldenmask
    sys.exit(goldenmask())
